/*************************************************
 * Task ass4 - bonus.
 * @author Ori Kopel <kopelor> <okopel@gmail.com> <205533151>
 * @version 1.0
 * @since 03-05-2018.
 ************************************************/
Hi checker, this is my simplication for the bonus mission:
 * x + (-x) --> 0
	=i compared the e1 with e2 of Neg so it has to be the same bevose getE2 is wothout "()"
* (-y) / (-x) --> (y) / (x)
	=i checked if e1 and e2 are Neg so i returned them without the Neg
 * sin^2(x) + cos^2(x) = 1
	=I checked if e1 and e2 are Pow and if e1.e1 and e2.e1 if sin and cos (or cos and sin) and if e2.e2 and e2.e2 are "2.0" so its 1.
 * exp^0 --> 1
	=I checked the e2 value, if this is 0 so it doesnt matter what e1 is.
 * log(x+y,y+x)=1
	=I comperd e1 and e2 by string and by reverse string (by special func that make (e1+e2 and e2+e1)).
 * log(x+y,1)=0
	=I checked e2 the vakue of e2. if 1 so it doesnt matter what e1 is.
 * x^1 --> x
	=I checked the e2 value, if this is 1 so it doesnt matter what e1 is.
 * x*x --> x^2
	=I checked if e1 = e2 so it doesnt matter what is the exp, we pow it by 2.
 * (x * y) - (y * x) -->0
	= i checked the reverse printing (e2 and than e1) and if equal --> 1
 * (exp)+(exp) --> 2 * exp
	=I checked if e1 = e2 so it doesnt matter what is the exp, we mult it by 2.
 * x^-1 -->1/x
	=I checked if e2<0  so it doesnt matter what is the exp in e1, we div it as 1/(exp^-a)
 * x * 2 --> 2 * x
	=I checked if e1 is Var and e2 isnt var. if yes i replaced tham.
 * 2x + 4x --> 6x || x + x ->> 2x
	=after the prev simplify, that it eassy to comapre the both e1 and the both e2 and connect tham if possible.
 * x^-a -->1/(x^a)
	=I checked if e2<0  so it doesnt matter what is the exp in e1, we div it as 1/(exp^-a)
 * (a/b) / (c/d) --> (a*d) / (b*c)
	=I checked if e1 and e2 are div and if yes - i multed the son of son of them.
 * x^y^z --> x^(y*z)
	=I checked if e1 is Pow so i returned new pow with mult in e2.
 * (x^a) / (y^a) --> (x/y)^a
	=I checked if e1 and e2 are Pow and if e2 equal to e1 by e2Child so i returned new div with this pow.
 * (x^a) / (x^b) --> x^(a-b)
	=I checked if e1 and e2 are Pow and if e2 equal to e1 by e1Child so i returned new div with this pow.
 * x^a * x^b --> x^(a+b)
	=I checked if e1 and e2 are Pow and if e2 equal to e1 by e2Child so i returned new plus with this pow.
 * x^a * y^a --> (x*y)^a
	=I checked if e1 and e2 are Pow and if e2 equal to e1 by e2Child so i returned new Mult with this pow.
 * --a --> a
	=I checked if e1 is Neg or has negative value and return Num instead of Neg.
 * (x+y) / (y+x) --> 1
	=I checked if e1 and e2 are Plus and if e2 equal to e1 or the e2 in reverse (function that i made the returned
	 (e2 +  "+" + e1) instead of (e1 +  "+" + e2) so if there is comparation- its 1.
* (x*y) / (y*x) --> 1
	=I checked if e1 and e2 are Mult and if e2 equal to e1 or the e2 in reverse (function that i made the returned
	 (e2 +  "*" + e1) instead of (e1 +  "*" + e2) so if there is comparation- its 1.
 * (2 * x) * (3 * x) --> 6 * (x^2)
	=I checked if e1  in the both of than is numbers and if e2 is the same exp so of yes - mult of number it easy and mult of Var is pow.
 * a^(log(a,b) --> b
	=I checked if e1  is equal to e1 in log.

----END---